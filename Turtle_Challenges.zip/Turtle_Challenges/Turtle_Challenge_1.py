from turtle import Turtle, Screen

t = Turtle()


t.shape("arrow")
t.color("red")

for _ in range(4):
    t.forward(100)
    t.right(90)

s = Screen()
s.exitonclick()
