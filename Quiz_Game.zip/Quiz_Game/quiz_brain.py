# ask the questions
# check if answer is correct
# check if end of quiz

class Qb:
    def __init__(self, q_list):
        self.question_number = 0
        self.question_list = q_list
        self.score = 0

    def next_question(self, ):
        current_q = self.question_list[self.question_number]
        self.question_number += 1
        ans = input(f"Q.{self.question_number}: {current_q.question} (True/False): ")
        self.check_ans(ans, current_q.answer )

    def still_has_questions(self) -> bool:
        return self.question_number < len(self.question_list)

    def check_ans(self, ans, correct) -> bool:
        if ans[0].lower() == correct[0].lower():
            self.score += 1
            print("You got it right!")
        else:
            print("that's wrong")
        print(f"The correct answer was {correct}.")
        print(f"your current score is: {self.score}/{self.question_number}")
        print("\n")
