from data import question_data
from question_model import Question
from quiz_brain import Qb

question_bank = []

for question in question_data:
    q_text, q_ans = question["text"], question["answer"]
    new_q = Question(q_text, q_ans)
    question_bank.append(new_q)

quiz = Qb(question_bank)

while quiz.still_has_questions():
    quiz.next_question()

print("Youve completed the quiz")
print(f"final score was {quiz.score}/{len(question_bank)}")