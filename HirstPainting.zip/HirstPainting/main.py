import colorgram
from turtle import Turtle, Screen
import random as rd

t = Turtle()
t.penup()
t.width(10)
t.goto(-320, 280)
t.hideturtle()
t.speed("fastest")

s = Screen()
s.colormode(255)
#the colors list is populated through the colorgram package with a for loop
colors = [(202, 139, 78), (155, 169, 57), (150, 64, 97), (234, 232, 229), (40, 63, 102), (158, 82, 59), (143, 33, 39),
          (62, 83, 118), (194, 141, 167), (59, 27, 25), (153, 31, 28), (179, 93, 121), (227, 192, 214), (193, 212, 224),
          (222, 172, 200), (143, 163, 182), (187, 99, 82), (220, 203, 98), (152, 184, 150), (31, 55, 85),
          (204, 218, 211), (166, 204, 211), (109, 120, 158), (169, 205, 188), (41, 66, 37), (224, 177, 167),
          (73, 145, 168), (225, 204, 22)]

for _ in range(12):
    for _ in range(14):
        t.pencolor(rd.choice(colors))
        t.dot(15)
        t.goto(t.xcor() + 50, t.ycor())
    t.goto(-320, t.ycor() - 50)


# colors = colorgram.extract('image.jpg', 30)
# # for color in colors:
# #     r = color.rgb.r
# #     g = color.rgb.g
# #     b = color.rgb.b
# #     new_col = (r, g, b)
# #     rgb_colors.append(new_col)
# #
# # print(rgb_colors)


s.exitonclick()