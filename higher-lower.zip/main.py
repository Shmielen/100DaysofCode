import art
from game_data import data
import random as rd
from replit import clear


def Gui():
  """prints the GUI and acts as main function for the game"""
  
  def compare(guess, a, b):
    """compares a and be follow count"""
    if a['follower_count'] > b['follower_count']:
      answer = a
    else:
      answer = b

    if answer == a and guess == "a":
      return True
    elif answer == b and guess == "b":
      return True
    else:
      return False

  score = 0 
  cont = True
  while cont:
    
    print(art.logo)
    
    if score != 0:
      print(f"Youre Right! Current score is {score}.")
      a = b
    else:
      a = rd.choice(data)
    
    
    print(f"Compare A: {a['name']}, a {a['description']}, from {a['country']}")
    print(art.vs)
    
    b = rd.choice(data)
    
    if a == b:
      b = rd.choice(data)
    
    print(f"Against B: {b['name']}, a {b['description']}, from {b['country']}")
    
    guess = str(input("Who has more followers A or B: "))
    guess = guess.lower()
    
    if compare(guess, a, b) == True:
      score += 1
      clear()
    else:
      cont = False
      clear()
      print(art.logo)
      print(f"Sorry thats wrong! final score: {score}")

Gui()
