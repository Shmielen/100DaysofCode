from menu import Menu
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

cm = CoffeeMaker()
mm = MoneyMachine()
m = Menu()

is_on = True

while is_on:
  choice = input("What drink would you like? (espresso/latte/cappuccino) ")

  if choice.lower() == "report":
    cm.report()
  elif choice.lower() == "off":
    is_on = False
  else:
    if m.find_drink(choice) != None:
      if cm.is_resource_sufficient(m.find_drink(choice)) == True:
        if mm.make_payment((m.find_drink(choice)).cost) == True:
          cm.make_coffee(m.find_drink(choice))